// server.js
const express = require('express');
const app = express();
const db = require('./db');
const path = require('path');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));


app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { username, password, role } = req.body;

  try {
    let query = '';
    if (role === 'mentor') {
      query = 'SELECT * FROM Mentor WHERE name = ? AND password = ?';
    } else if (role === 'mentee') {
      query = 'SELECT * FROM Mentee WHERE name = ? AND password = ?';
    }

    const [rows] = await db.query(query, [username, password]);

    if (rows.length > 0) {
      const userId = role === 'mentor' ? rows[0].mentorid : rows[0].menteeid;

      console.log(`${role} logged in:`, rows[0]);

      res.redirect(`/homepage?role=${role}&id=${userId}&feedbackGiven=${false}`);
    } else {
      res.render('login', { error: 'Invalid username or password' });
    }
  } catch (err) {
    console.log(err);
    res.render('login', { error: 'Something went wrong. Try again.' });
  }
});


app.get('/create-account', (req, res) => {
  res.render('create-account', { error: null });
});

app.post('/create-account', async (req, res) => {
  const userdetails = req.body;

  try {
    if (userdetails.role === 'mentor') {
      const [rows] = await db.query('SELECT COUNT(*) AS count FROM Mentor');
      const count = rows[0].count + 101;

      const values = [
        count,
        userdetails.username,
        userdetails.experience,
        userdetails.linkedin,
        userdetails.password
      ];

      const insertQuery = 'INSERT INTO Mentor (mentorid, name, experience, Linkedin_profile, password) VALUES (?, ?, ?, ?, ?)';
      await db.query(insertQuery, values);

      res.render('create-account', { error: 'Account Created Successfully. Go to login page.' });

    } else if (userdetails.role === 'mentee') {
      const [rows] = await db.query('SELECT COUNT(*) AS count FROM Mentee');
      const count = rows[0].count + 1;

      const values = [
        count,
        userdetails.username,
        userdetails.currentCourse,
        userdetails.interests,
        userdetails.password
      ];

      const insertQuery = 'INSERT INTO Mentee (menteeid , name, CurrentCourse_or_Job, Interests, password) VALUES (?, ?, ?, ?, ?)';
      await db.query(insertQuery, values);

      res.render('create-account', { error: 'Account Created Successfully. Go to login page.' });
    }
  } catch (err) {
    console.error(err);
    res.render('create-account', { error: 'Error creating account' });
  }
});


app.get('/mentor/:id', async (req, res) => {
  const id = req.params.id;
  const [user] = await db.query('SELECT * FROM mentor WHERE mentorid = ?', [id]);
  if (user.length > 0) {
      res.render('mentor-profile', { details: user[0] });
  } else {
      res.status(404).send('No user found');
  }
});

app.get('/mentee/:id', async (req, res) => {
  const id = req.params.id;
  const [user] = await db.query('SELECT * FROM mentee WHERE menteeid = ?', [id]);
  if (user.length > 0) {
      res.render('mentee-profile', { details: user[0] });
  } else {
      res.status(404).send('No user found');
  }
});


app.get('/homepage', async (req, res) => {
  const { role, id, feedbakGiven } = req.query;

  try {
    let user = [];
    if (role === 'mentor') {
      [user] = await db.query('SELECT * FROM Mentor WHERE mentorid = ?', [id]);
    } else if (role === 'mentee') {
      [user] = await db.query('SELECT * FROM Mentee WHERE menteeid = ?', [id]);
    }

    const [mentees] = await db.query('SELECT * FROM Mentee');
    const [mentors] = await db.query('SELECT * FROM Mentor');

    if (user.length > 0) {
      const details = user[0];

      const query3 = `
        SELECT mentor.name AS M_name, mentee.name AS m_name, slotbooking.status, 
              slotbooking.interaction_date, slotbooking.slotid, slotbooking.interaction_time 
        FROM slotbooking 
        JOIN mentee ON mentee.menteeid = slotbooking.menteeid 
        JOIN mentor ON mentor.mentorid = slotbooking.mentorid 
        WHERE ${role}.` + (role === 'mentor' ? 'mentorid' : 'menteeid') + ` = ?`;

      const [sessions] = await db.query(query3, [id]);

      res.render('homepage', {
        details,
        usertype: role,
        sessions,
        mentors,
        mentees,
        feedbakGiven
      });
    } else {
      res.status(404).send('User not found');
    }

  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});


app.post('/submit-feedback', async (req, res) => {
  const { slotid, usertype, feedback, userId } = req.body;

  const column = usertype === 'mentor' ? 'mentor_Feedback' : 'mentee_Feedback';

  try {
    const [rows] = await db.query('SELECT * FROM interaction WHERE slotid = ?', [slotid]);

    if (rows.length > 0) {

      const updateQuery = `UPDATE interaction SET ${column} = ? WHERE slotid = ?`;
      await db.query(updateQuery, [feedback, slotid]);
    } else {

      const [slotRows] = await db.query('SELECT mentorid, menteeid FROM slotbooking WHERE slotid = ?', [slotid]);

      if (slotRows.length > 0) {
        const { mentorid, menteeid } = slotRows[0];

        const insertQuery = `
          INSERT INTO interaction (slotid, mentorid, menteeid, ${column})
          VALUES (?, ?, ?, ?)
        `;
        await db.query(insertQuery, [slotid, mentorid, menteeid, feedback]);
      } else {
        return res.status(404).send('Slot not found.');
      }
    }

    res.redirect(`/homepage?role=${usertype}&id=${userId}&feedbackGiven=${true}`);
  } catch (err) {
    console.error('Error handling feedback:', err);
    res.status(500).send('Something went wrong.');
  }
});



app.post('/book-session/:menteeid', async (req, res) => {
  try {
    const { menteeid } = req.params;
    const { date, mentorId, timeSlot } = req.body;
    if (!mentorId || isNaN(mentorId)) {
      return res.status(400).send("Invalid mentorId");
    }
    const checkQuery = 'SELECT * FROM slotbooking WHERE mentorid = ? AND interaction_date = ? AND interaction_time = ?';
    const [details] = await db.query(checkQuery, [mentorId, date, timeSlot]);

    if (details.length > 0) {
      console.log('That Slot is not available');
      return res.status(400).send('That Slot is not available');
    }

    const cntQuery = "SELECT COUNT(slotid) AS count FROM slotbooking";
    const [result] = await db.query(cntQuery);
    const countValue = result[0].count;

    const insertQuery = "INSERT INTO slotbooking (slotid, mentorid, menteeid, interaction_date, status, interaction_time) VALUES (?, ?, ?, ?, ?, ?)";
    await db.query(insertQuery, [countValue + 1, mentorId, menteeid, date, "pending", timeSlot]);

    console.log("Slot booked successfully");
    res.send(`<script>alert("Session booked successfully."); window.location.href="/homepage?role=mentee&id=${menteeid}&feedbackGiven=false";</script>`);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error. Please try again.");
  }
});

app.post('/handle-request', async (req, res) => {
  const { slotId, flag } = req.body;
  const query = "UPDATE slotbooking SET status = ? WHERE slotid = ?";

  try {
    if (flag) {
      await db.query(query, ["booked", slotId]);
    } else {
      await db.query(query, ["rejected", slotId]);
    }

    res.json({ message: "Slot status updated successfully" }); 
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update slot status" }); 
  }
});


app.delete('/delete-account/mentor/:id', async (req, res) => {
  const userId = req.params.id;
  try {
    await db.query('DELETE FROM mentor WHERE mentorid = ?', [userId]);
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting mentor account:", error);
    res.json({ success: false });
  }
});





app.delete('/delete-account/mentee/:id', async (req, res) => {
  const userId = req.params.id;
  try {
    await db.query('DELETE FROM mentee WHERE menteeid = ?', [userId]);
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting mentee account:", error);
    res.json({ success: false });
  }
});








app.listen(3000, () => {
  console.log('Server running on port 3000');
});